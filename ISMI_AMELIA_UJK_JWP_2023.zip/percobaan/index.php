<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Pendaftran Sertifikasi</title>
 
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    <a class="navbar-brand" href="#">
      <img src="logo.png" alt="Bootstrap" width="30" height="24">
    </a>
    <a class="navbar-brand" href="#">
      <img src="LOGO-LSPTIKOM.jpeg" alt="Bootstrap" width="30" height="24">
    </a>
      <a class="navbar-brand" href="#">Sertifikasi TIKOM Bersama Universitas Teknologi Digital</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="lihat.php">data peserta</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="form_pendaftaran.php">daftar sertifikasi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">login admin</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="jumbotron">
    <h1> SELAMAT DATANG DI HALAMAN WEBSITE</h1>
    <p>Peserta Sertifikasi Kompeten Digitech University LSP TIKOM</p>
  </div>
</div>

</body>
</html>
